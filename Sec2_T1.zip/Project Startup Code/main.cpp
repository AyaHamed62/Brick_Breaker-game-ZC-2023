#include "game.h"


int main()
{

	//Create an object of controller
	game Game;
	Game.go();

	
	return 0;
}

